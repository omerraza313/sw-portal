<?php

namespace App\Http\Controllers;

use App\Models\ServicePackage;
use Illuminate\Http\Request;

class ServicePackageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ServicePackage  $servicePackage
     * @return \Illuminate\Http\Response
     */
    public function show(ServicePackage $servicePackage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ServicePackage  $servicePackage
     * @return \Illuminate\Http\Response
     */
    public function edit(ServicePackage $servicePackage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ServicePackage  $servicePackage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ServicePackage $servicePackage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ServicePackage  $servicePackage
     * @return \Illuminate\Http\Response
     */
    public function destroy(ServicePackage $servicePackage)
    {
        //
    }
}
