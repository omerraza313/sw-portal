<?php

namespace App\Http\Controllers;

use App\Models\ServiceWorkingDay;
use Illuminate\Http\Request;

class ServiceWorkingDayController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ServiceWorkingDay  $serviceWorkingDay
     * @return \Illuminate\Http\Response
     */
    public function show(ServiceWorkingDay $serviceWorkingDay)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ServiceWorkingDay  $serviceWorkingDay
     * @return \Illuminate\Http\Response
     */
    public function edit(ServiceWorkingDay $serviceWorkingDay)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ServiceWorkingDay  $serviceWorkingDay
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ServiceWorkingDay $serviceWorkingDay)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ServiceWorkingDay  $serviceWorkingDay
     * @return \Illuminate\Http\Response
     */
    public function destroy(ServiceWorkingDay $serviceWorkingDay)
    {
        //
    }
}
