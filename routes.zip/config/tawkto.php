<?php

return [

    /*
    |--------------------------------------------------------------------------
    | tawk.to Direct Chat Link
    |--------------------------------------------------------------------------
    |
    | The "Direct Chat Link" URL from your admin dashboard at:
    | https://dashboard.tawk.to/#/admin/chat-widget
    |
    */
    'link' => env('TAWKTO_LINK'),

];
